export const environment = {
    production: false,
    apiUrl: 'https://localhost:7211/api'  // Adjust based on your API URL
  };